#/bin/sh

java -jar collectionTreeModel-2015.04.20.jar
